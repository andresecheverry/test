/*
 * main.cpp
 *
 *  Created on: Jun 25, 2016
 *      Author: andres.echeverry
 */

#include<iostream>
#include<vector>


using namespace std;

string getInput();
string sh_yard(string);

int main()
{
	string input;

	string output;

	// Collect a string from the console

	input = getInput();

	while (input != "exit")
	{
		output = sh_yard(input);

		cout << output << endl;

		input = getInput();
	}

	return 0;

}

