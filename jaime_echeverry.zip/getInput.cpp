/*
 * getInput.cpp
 *
 *  Created on: Jun 25, 2016
 *      Author: andres.echeverry
 */


#include<iostream>
#include<vector>

using namespace std;

string getInput()
{
	string input;
	bool emptyInput = false;

	do
	{
		cout << "> " ;

		getline(cin, input);

		if (input.empty())
		{
			cout << "No input provided." << endl;
			emptyInput = true;
		} else emptyInput = false;

	} while (emptyInput);

	return input;
}




