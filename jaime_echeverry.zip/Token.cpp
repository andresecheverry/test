/*
 * token.cpp
 *
 *  Created on: Jun 25, 2016
 *      Author: andres.echeverry
 */

#include "Token.h"
#include <iostream>

using namespace std;

Token::Token(vector<char> input){
	token = input;
	_isNumber = false;
	_isFunction = false;
	_isOperator = false;
	_operatorPrecedence = 0;
	_isLeftAssociative = false;
	_isLeftParenthesis = false;
	_isRightParenthesis = false;
	classifyToken();
}

Token::~Token(){
	token.clear();
}

bool Token::isNumber()
{
	return _isNumber;
}

bool Token::isFunction()
{
	return _isFunction;
}

bool Token::isOperator()
{
	return _isOperator;
}

int Token::operatorPrecedence()
{
	return _operatorPrecedence;
}

bool Token::isLeftAssociative()
{
	return _isLeftAssociative;
}

bool Token::isLeftParenthesis()
{
	return _isLeftParenthesis;
}

bool Token::isRightParenthesis()
{
	return _isRightParenthesis;
}

string Token::getString()
{
	string str(token.begin(),token.end());
	return str;
}

int Token::size(){
	return token.size();
}

void Token::print(){
	for (vector<char>::const_iterator i = token.begin(); i != token.end(); ++i)
	{
	    cout << *i;
	}
	cout << endl;
    cout << "is Number: " << _isNumber << endl;
    cout << "is Function: " << _isFunction << endl;
    cout << "is Operator: " << _isOperator << endl;
    cout << "operator precedence: " << _operatorPrecedence << endl;
    cout << "is left associative: " << _isLeftAssociative << endl;
    cout << "is LeftParenthesis: " << _isLeftParenthesis << endl;
    cout << "is RightParenthesis: " << _isRightParenthesis << endl;
    cout << "size: " << token.size() << endl;

}

void Token::classifyToken()
{
	switch (token[0])
	{
		case 40:
			_isLeftParenthesis = true;
			break;

		case 41:
			_isRightParenthesis = true;
			break;

		case 42: // *
			_isOperator = true;
			_operatorPrecedence = 3;
			_isLeftAssociative = true;
			break;

		case 43: // +
			_isOperator = true;
			_operatorPrecedence = 2;
			_isLeftAssociative = true;
			break;

		case 45: // -
			_isOperator = true;
			_operatorPrecedence = 2;
			_isLeftAssociative = true;
			break;

		case 47: // "/" division
			_isOperator = true;
			_operatorPrecedence = 3;
			_isLeftAssociative = true;
			break;

		case 48: // 0
			_isNumber = true;
			break;

		case 49: // 1
			_isNumber = true;
			break;

		case 50: // 2
			_isNumber = true;
			break;

		case 51: // 3
			_isNumber = true;
			break;

		case 52: // 4
			_isNumber = true;
			break;

		case 53: // 5
			_isNumber = true;
			break;

		case 54: // 6
			_isNumber = true;
			break;

		case 55: // 7
			_isNumber = true;
			break;

		case 56: // 8
			_isNumber = true;
			break;

		case 57: // 9
			_isNumber = true;
			break;

		case 94: //
			_isOperator = true;
			_operatorPrecedence = 4;
			_isLeftAssociative = false;
			break;

		case 114:
			if (token[1] == 116)
			{
				_isFunction = true;
			}
			break;

		default:
			break;
	}
}



