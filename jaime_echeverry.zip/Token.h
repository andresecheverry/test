/*
 * token.h
 *
 *  Created on: Jun 25, 2016
 *      Author: andres.echeverry
 */

#ifndef TOKEN_H_
#define TOKEN_H_
#include<vector>
#include<iostream>

using namespace std;

class Token
{
	public:
		Token(vector<char> input);
		~Token();
		bool isNumber();
		bool isFunction();
		bool isOperator();
		int operatorPrecedence();
		bool isLeftAssociative();
		bool isLeftParenthesis();
		bool isRightParenthesis();
		string getString();
		void print();
		int size();

	private:
		vector<char> token;
		void classifyToken();
		int type;
		bool _isNumber;
		bool _isFunction;
		bool _isOperator;
		int _operatorPrecedence;
		bool _isLeftAssociative;
		bool _isLeftParenthesis;
		bool _isRightParenthesis;
};

#endif /* TOKEN_H_ */
