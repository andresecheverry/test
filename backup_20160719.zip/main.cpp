/*
 * main.cpp
 *
 *  Created on: Jun 25, 2016
 *      Author: andres.echeverry
 */

#include<iostream>
#include<vector>
#include<stdexcept>


using namespace std;

string getInput();
string sh_yard(string);

int main()
{
	string input;

	string output;

	// Collect a string from the console

	input = getInput();

	while (input != "exit")
	{
		try
		{
			output = sh_yard(input);
			cout << output << endl;

		} catch (runtime_error &err)
		{
			cerr << endl << err.what()<< endl;
		}

		input = getInput();
	}
	return 0;
}

